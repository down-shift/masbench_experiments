# Anonymous supplement

From the extracted directory, reproduce the 8B analysis offline:

    uv run --offline --no-project --python 3.12 python confirmation.py analyze --plan plans/confirmation-main.json --original runs/confirmation-a-first --reversed runs/confirmation-b-first --out results.json

Expected: 56 correct under both orders, eight corrected by reversal, and a 12.5-point difference (95% scenario bootstrap interval 4.6875 to 20.3125 points). Each result.json stores the exact prompt and saved response. The source plan records selected scenario IDs and the pinned upstream dataset commit.

To audit selection counts:

    uv run --offline --no-project --python 3.12 python confirmation.py prepare --exclude plans/order-smoke.json plans/order-main.json --audit-only

There were 200 audited cases, 123 eligible for reconstruction, and 87 remaining after exclusions. The source plan records that all 87 satisfied the single-holder candidate rule. The frozen confirmation plan contains the sampled 32 and their oracle labels. The exact 8B checkpoint revision remains unavailable.

## Exploratory 4B label extraction

All 64 responses per order were multiline and failed exact format after trimming outer whitespace. Four A-first and six B-first outputs reached the token limit. Both manifests requested enable_thinking=false. Searching each raw response for occurrences of FINAL A or FINAL B with word boundaries and retaining responses with exactly one occurrence yielded 60/60 correct for A-first and 56/57 correct for B-first. This rule was selected after inspecting the outputs. The remaining responses are unclassified and the retained subsets differ by order.
